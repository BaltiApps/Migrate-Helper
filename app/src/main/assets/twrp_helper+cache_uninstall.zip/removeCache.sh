#!sbin/sh

rm -rf /data/local/tmp/migrate_cache
rm /data/data/*.tar.gz