#!sbin/sh

SYSTEM=""
OUTFD=""

for FD in `ls /proc/$$/fd`; do
    if readlink /proc/$$/fd/$FD | grep -q pipe; then
        if ps | grep -v grep | grep -q " 3 $FD "; then
            OUTFD=${FD}
            break
        fi
    fi
done

echoIt() {
    if [[ -n "${OUTFD}" ]]; then
        echo "ui_print $1" >> /proc/self/fd/${OUTFD};
    else
        echo "FD $OUTFD:: $1"
    fi
}

echoIt " "

if [[ -d /system_root/system/app ]]; then
    SYSTEM=/system_root/system

elif [[ -d /system_root/app ]]; then
    SYSTEM=/system_root

elif [[ -d /system/system/app ]]; then
    SYSTEM=/system/system

elif [[ -d /system/app ]]; then
    SYSTEM=/system

fi

if [[ -e ${SYSTEM}/product/app ]]; then
    SYSTEM="${SYSTEM}/product"
fi

if [[ ${SYSTEM} != "" ]]; then
    echoIt "System app confirmed under: $SYSTEM"
    sleep 1s
else
    echoIt "System app detection failed!"
    exit 1
fi

HELPER="${SYSTEM}/app/MigrateHelper"

if [[ -d $HELPER ]]; then
    echoIt "Deleting helper"
    rm -rf $HELPER
else
    echoIt "!!! Helper not found !!!"
fi

echoIt " "
